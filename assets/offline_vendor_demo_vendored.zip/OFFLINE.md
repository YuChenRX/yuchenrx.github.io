# offline_vendor_demo — Offline Usage Guide

This workspace is designed to be **built and tested completely offline** using Cargo’s `vendor/` mode.

## What’s inside

- `backend/`: Axum + Tokio web server
  - `GET /health` → JSON `{ "status": "ok" }`
  - `GET /api/echo` → JSON `{ "message": "hello from axum" }`
  - Serves static files from `web/` at `/`
- `wasm/`: `wasm-bindgen` + `web-sys` demo library
  - `greet(name)` / `greet_json(name)` exported for `wasm32-unknown-unknown`
- `vendor/`: vendored crate sources (all dependencies)
- `.cargo/config.toml`: forces Cargo to use `vendor/` and go offline

## Prerequisites on the offline machine

1. Rust toolchain installed (via `rustup` or system installer)
2. The `wasm32-unknown-unknown` target installed **if you want to build/check the wasm crate for wasm32**:

```bash
rustup target add wasm32-unknown-unknown
```

Notes:
- This project does **not** require Node.js.
- This project does **not** require `wasm-pack` / `trunk` / `wasm-bindgen-cli` because we only validate via `cargo check`.
  If you want browser-ready JS glue output, you’ll need an additional toolchain.

## Build & test (offline)

From the workspace root (the folder containing `Cargo.toml`):

```bash
cargo test --locked --offline
```

That compiles both crates and runs unit tests.

### Verify the wasm crate for wasm32 (offline)

```bash
cargo check -p wasm --target wasm32-unknown-unknown --locked --offline
```

## Run the backend (offline)

```bash
cargo run -p backend --locked --offline
```

Then open in your browser:

- `http://127.0.0.1:3000/`
- `http://127.0.0.1:3000/health`
- `http://127.0.0.1:3000/api/echo`

## Common problems (offline)

### 1) Cargo tries to access the network

This repo includes `.cargo/config.toml` with:

- `[source.crates-io] replace-with = "vendored-sources"`
- `[net] offline = true`

If you copied the whole folder (including `.cargo/` and `vendor/`), Cargo should not touch the network.

### 2) Windows unzip/path issues

`vendor/` can create deep directory trees. If your unzip tool doesn’t support long paths, builds may fail.

Workarounds:
- unzip to a short path, e.g. `C:\work\offline_vendor_demo`
- enable Windows long paths (Group Policy / registry) if you control the machine

### 3) You changed dependencies

If you edit `Cargo.toml` (add/remove deps or features), you must re-vendor on a machine that can resolve deps:

```bash
cargo update
cargo vendor vendor
```

Then copy the updated `vendor/` + `Cargo.lock`.
