use serde::{Deserialize, Serialize};

#[cfg(target_arch = "wasm32")]
use wasm_bindgen::prelude::*;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Greeting {
    pub message: String,
}

pub fn add(left: u64, right: u64) -> u64 {
    left + right
}

#[cfg(target_arch = "wasm32")]
#[wasm_bindgen(start)]
pub fn start() {
    console_error_panic_hook::set_once();
    web_sys::console::log_1(&"wasm module initialized".into());
}

#[cfg(target_arch = "wasm32")]
#[wasm_bindgen]
pub fn greet(name: &str) -> String {
    format!("Hello, {name}! (from wasm)")
}

#[cfg(not(target_arch = "wasm32"))]
pub fn greet(name: &str) -> String {
    format!("Hello, {name}! (non-wasm build)")
}

#[cfg(target_arch = "wasm32")]
#[wasm_bindgen]
pub fn greet_json(name: &str) -> JsValue {
    let greeting = Greeting {
        message: format!("Hello, {name}!"),
    };

    serde_wasm_bindgen::to_value(&greeting).expect("serialize Greeting")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn add_works() {
        assert_eq!(add(2, 2), 4);
    }

    #[test]
    fn greet_works_on_host() {
        let msg = greet("world");
        assert!(msg.contains("world"));
    }
}
